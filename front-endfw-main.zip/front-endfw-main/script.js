// function darkmode(){

//     document.body.style.background = 'grey'
//     document.body.style.color = 'white'
// }
// function lightmode(){

//     document.body.style.background = 'white'
//     document.body.style.color = 'black'
// }



// let flag = true

// function mode(){
//     if (flag == true){
//         document.body.style.background = 'grey'
//         document.body.style.color = 'white'
//         flag = !flag
//     }else{
//         document.body.style.background = 'white'
//         document.body.style.color = 'black'
//         flag = !flag
//     }
// }
function mode(){
    if (document.body.style.background == 'grey'){
        document.body.style.background = 'white'
        document.body.style.color = 'black'
    }else{
        document.body.style.background = 'grey'
        document.body.style.color = 'white' 
    }
}